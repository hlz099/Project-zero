#!/bin/bash

javac.exe -Xlint Driver.java
java Driver